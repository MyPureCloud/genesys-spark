export const VISUALIZATION_COLORS = [
  '#203B73',
  '#1DA8B3',
  '#75A8FF',
  '#8452CF',
  '#B5B5EB',
  '#CC3EBE',
  '#5E5782',
  '#FF8FDD',
  '#868C1E',
  '#DDD933'
];
