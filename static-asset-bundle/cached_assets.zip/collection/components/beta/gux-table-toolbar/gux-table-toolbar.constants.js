/**
 * Below is the minimum spacing in px that is required between,
 * the controls aligned to the left and controls aligned to the right.
 */
export const MIN_CONTROL_SPACING = 72;
