/**
 * Below are the max-widths for the blank state component.
 */
export const SMALL_STATE = 160;
export const MEDIUM_STATE = 300;
