/**
 * Below are the max-widths for the loading component.
 */
export const SMALL_LOADING_MESSAGE = 160;
export const MEDIUM_LOADING_MESSAGE = 300;
