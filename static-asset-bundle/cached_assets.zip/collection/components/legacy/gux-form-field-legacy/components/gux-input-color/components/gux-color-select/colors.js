// Default color values
export const defaultColors = [
  '#203B73',
  '#75A8FF',
  '#8452CF',
  '#1DA8B3',
  '#B5B5EB',
  '#CC3EBE',
  '#5E6782',
  '#FF8FDD',
  '#868C1E',
  '#DDD933'
];
